# Contoh view - dokumentasi
from django.shortcuts import render
from .models import Kelurahan

def index(request):
    kelurahan_list = Kelurahan.objects.all()
    return render(request, 'data_kelurahan/index.html', {'items': kelurahan_list})
