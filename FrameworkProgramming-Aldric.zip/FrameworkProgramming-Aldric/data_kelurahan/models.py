# Contoh model - untuk dokumentasi saja
from django.db import models

class Kelurahan(models.Model):
    nama = models.CharField(max_length=100)
    kecamatan = models.CharField(max_length=100)
    def __str__(self):
        return self.nama
