# FrameworkProgramming-Aldric

Project dibuat untuk tugas Framework Programming (Modul 1–4).  
Pemilik / Penulis: **Aldric Devlinalldo**

## Deskripsi singkat
Repo ini berisi project contoh berbasis Django-style (struktur & file) yang berisi progres per modul.  
Project sudah disederhanakan agar mudah di-review dan di-upload lewat iPhone (Working Copy).

## Cara upload di iPhone (Working Copy)
1. Unzip file `FrameworkProgramming-Aldric.zip` di app **Files**.
2. Buka **Working Copy** → pilih repo `FrameworkProgramming_Aldric` → **+ → Import Files**.
3. Pilih folder hasil unzip dan import.
4. Commit + Push ke GitHub.

## Struktur
- modul1/ : Setup awal, README modul & contoh HTML index
- modul2/ : Menambahkan model kelurahan (dummy file) + halaman list
- modul3/ : Menambahkan model warga (dummy) + relasi contoh
- modul4/ : Validasi & styling sederhana + final README

## Nama
- Project author: Aldric Devlinalldo
