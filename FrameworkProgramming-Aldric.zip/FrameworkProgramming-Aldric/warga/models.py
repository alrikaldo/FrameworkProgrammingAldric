# Contoh model warga - dokumentasi
from django.db import models
from data_kelurahan.models import Kelurahan

class Warga(models.Model):
    nama = models.CharField(max_length=100)
    umur = models.IntegerField()
    kelurahan = models.ForeignKey(Kelurahan, on_delete=models.CASCADE)
