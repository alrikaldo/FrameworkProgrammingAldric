# Modul Summary (1-4)

Modul 1: Setup awal — README, struktur folder, index.html modul1.
Modul 2: Tambah contoh model kelurahan + index page modul2.
Modul 3: Tambah contoh model warga + relasi contoh + index page modul3.
Modul 4: Styling, validasi sederhana, final README + index page modul4.

Author: Aldric Devlinalldo
